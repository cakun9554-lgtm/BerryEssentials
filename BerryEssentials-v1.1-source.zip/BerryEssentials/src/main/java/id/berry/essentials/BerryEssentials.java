package id.berry.essentials;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class BerryEssentials extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Double> wallet = new ConcurrentHashMap<>();
    private final Map<UUID, Double> bank = new ConcurrentHashMap<>();
    private final Map<UUID, String> ranks = new ConcurrentHashMap<>();
    private final Map<UUID, String> clans = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> kills = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> deaths = new ConcurrentHashMap<>();
    private final Map<String, UUID> clanOwners = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, String>> homes = new ConcurrentHashMap<>();
    private final MiniMessage mm = MiniMessage.miniMessage();
    private File dataFile;
    private org.bukkit.configuration.file.YamlConfiguration data;

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("money","pay","bank","setrank","clan","membermenu","adminmenu","sethome","home","delhome","setwarp","warp")) {
            PluginCommand c = getCommand(name);
            if (c != null) c.setExecutor(this);
        }
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    syncNametag(p);
                    updateBoard(p);
                }
            }
        }.runTaskTimer(this, 20L, 20L);
        getLogger().info("BerryEssentials enabled.");
    }

    @Override public void onDisable() { saveData(); }

    private void loadData() {
        if (!dataFile.getParentFile().exists()) dataFile.getParentFile().mkdirs();
        data = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(dataFile);
        for (String key : data.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                wallet.put(id, data.getDouble(key + ".wallet", getConfig().getDouble("economy.starting-balance", 100)));
                bank.put(id, data.getDouble(key + ".bank", 0));
                ranks.put(id, data.getString(key + ".rank", "Member"));
                String clan = data.getString(key + ".clan", "");
                if (!clan.isBlank()) clans.put(id, clan);
                kills.put(id, data.getInt(key + ".kills", 0));
                deaths.put(id, data.getInt(key + ".deaths", 0));
            } catch (IllegalArgumentException ignored) {}
        }
        for (String clan : getConfig().getConfigurationSection("clans") == null ? Set.<String>of() : getConfig().getConfigurationSection("clans").getKeys(false)) {
            String owner = getConfig().getString("clans." + clan + ".owner");
            if (owner != null) try { clanOwners.put(clan.toLowerCase(Locale.ROOT), UUID.fromString(owner)); } catch (Exception ignored) {}
        }
    }

    private void saveData() {
        if (data == null) return;
        Set<UUID> ids = new HashSet<>();
        ids.addAll(wallet.keySet()); ids.addAll(bank.keySet()); ids.addAll(ranks.keySet());
        ids.addAll(clans.keySet()); ids.addAll(kills.keySet()); ids.addAll(deaths.keySet());
        for (UUID id : ids) {
            String k = id.toString();
            data.set(k + ".wallet", wallet.getOrDefault(id, 0d));
            data.set(k + ".bank", bank.getOrDefault(id, 0d));
            data.set(k + ".rank", ranks.getOrDefault(id, "Member"));
            data.set(k + ".clan", clans.getOrDefault(id, ""));
            data.set(k + ".kills", kills.getOrDefault(id, 0));
            data.set(k + ".deaths", deaths.getOrDefault(id, 0));
        }
        try { data.save(dataFile); } catch (Exception ex) { getLogger().severe("Could not save data.yml: " + ex.getMessage()); }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer(); UUID id = p.getUniqueId();
        wallet.putIfAbsent(id, getConfig().getDouble("economy.starting-balance", 100));
        bank.putIfAbsent(id, 0d); ranks.putIfAbsent(id, "Member");
        kills.putIfAbsent(id, 0); deaths.putIfAbsent(id, 0);
        syncNametag(p); updateBoard(p); saveData();
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) { saveData(); }

    @EventHandler public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        deaths.merge(victim.getUniqueId(), 1, Integer::sum);
        Player killer = victim.getKiller();
        if (killer != null) kills.merge(killer.getUniqueId(), 1, Integer::sum);
        Bukkit.getScheduler().runTask(this, () -> {
            updateBoard(victim);
            if (killer != null && killer.isOnline()) updateBoard(killer);
            saveData();
        });
    }

    private void updateBoard(Player p) {
        if (!getConfig().getBoolean("scoreboard.enabled", true)) return;
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("berry", Criteria.DUMMY, mm.deserialize(getConfig().getString("scoreboard.title")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        List<String> lines = getConfig().getStringList("scoreboard.lines");
        int score = lines.size();
        Set<String> used = new HashSet<>();
        for (String raw : lines) {
            String line = replace(raw, p);
            String unique = line;
            while (!used.add(unique)) unique = line + "§" + Integer.toHexString(score & 15);
            obj.getScore(unique).setScore(score--);
        }
        p.setScoreboard(board);
    }

    private String replace(String s, Player p) {
        String clan = clans.getOrDefault(p.getUniqueId(), "-");
        int k = kills.getOrDefault(p.getUniqueId(), 0), d = deaths.getOrDefault(p.getUniqueId(), 0);
        double[] tps = Bukkit.getTPS();
        String tpsText = tps.length == 0 ? "20.0" : String.format(Locale.US, "%.1f", Math.min(20, tps[0]));
        return s.replace("%player%", p.getName())
                .replace("%money%", String.format(Locale.US, "%.2f", wallet.getOrDefault(p.getUniqueId(), 0d)))
                .replace("%clan%", clan)
                .replace("%rank%", ranks.getOrDefault(p.getUniqueId(), "Member"))
                .replace("%online%", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("%tps%", tpsText)
                .replace("%kd%", k + "/" + d)
                .replace("%dim%", p.getWorld().getEnvironment().name());
    }

    private void syncNametag(Player p) {
        Scoreboard board = p.getScoreboard();
        if (board == Bukkit.getScoreboardManager().getMainScoreboard()) {
            board = Bukkit.getScoreboardManager().getNewScoreboard();
            p.setScoreboard(board);
        }
        String rank = ranks.getOrDefault(p.getUniqueId(), "Member");
        String colorName = getConfig().getString("ranks." + rank + ".color", "WHITE");
        ChatColor color;
        try { color = ChatColor.valueOf(colorName.toUpperCase(Locale.ROOT)); } catch (Exception ex) { color = ChatColor.WHITE; }
        String prefix = ChatColor.translateAlternateColorCodes('&', getConfig().getString("ranks." + rank + ".prefix", "&7[Member] "));
        String teamName = "be_" + rank.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (teamName.length() > 16) teamName = teamName.substring(0, 16);
        Team team = board.getTeam(teamName);
        if (team == null) team = board.registerNewTeam(teamName);
        team.setPrefix(prefix);
        team.setColor(color);
        team.addEntry(p.getName());
    }

    private void send(CommandSender s, String message) { s.sendMessage(ChatColor.translateAlternateColorCodes('&', "&d[Berry&6Essentials&d] &f" + message)); }
    private boolean isPlayer(CommandSender s) { if (s instanceof Player) return true; send(s, "Perintah ini hanya untuk player."); return false; }
    private double amount(String raw) { try { double v = Double.parseDouble(raw); return Double.isFinite(v) && v > 0 ? v : -1; } catch (Exception e) { return -1; } }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("money")) {
            if (!isPlayer(sender)) return true;
            Player p = (Player)sender;
            send(p, "Uang: " + getConfig().getString("economy.currency-symbol", "$") + wallet.getOrDefault(p.getUniqueId(), 0d));
            return true;
        }
        if (cmd.equals("pay")) {
            if (!isPlayer(sender)) return true;
            if (args.length != 2) { send(sender, "Gunakan: /pay <player> <jumlah>"); return true; }
            Player from = (Player)sender, to = Bukkit.getPlayerExact(args[0]);
            double n = amount(args[1]);
            if (to == null || to.equals(from) || n < 0 || wallet.getOrDefault(from.getUniqueId(),0d) < n) { send(sender, "Penerima atau jumlah tidak valid / saldo kurang."); return true; }
            wallet.put(from.getUniqueId(), wallet.get(from.getUniqueId()) - n);
            wallet.merge(to.getUniqueId(), n, Double::sum);
            send(from, "Transfer berhasil: " + n + " ke " + to.getName());
            send(to, "Kamu menerima " + n + " dari " + from.getName());
            updateBoard(from); updateBoard(to); saveData(); return true;
        }
        if (cmd.equals("bank")) {
            if (!isPlayer(sender)) return true;
            Player p = (Player)sender; UUID id = p.getUniqueId();
            if (args.length == 0) { send(p, "Bank: " + bank.getOrDefault(id,0d) + " | /bank deposit <jumlah> | /bank withdraw <jumlah>"); return true; }
            if (args.length != 2) { send(p, "Gunakan /bank deposit|withdraw <jumlah>"); return true; }
            double n = amount(args[1]); if (n < 0) { send(p, "Jumlah tidak valid."); return true; }
            double w = wallet.getOrDefault(id,0d), b = bank.getOrDefault(id,0d);
            if (args[0].equalsIgnoreCase("deposit") && w >= n) { wallet.put(id,w-n); bank.put(id,b+n); }
            else if (args[0].equalsIgnoreCase("withdraw") && b >= n) { bank.put(id,b-n); wallet.put(id,w+n); }
            else { send(p, "Saldo tidak cukup."); return true; }
            send(p, "Transaksi berhasil. Wallet: " + wallet.get(id) + " | Bank: " + bank.get(id));
            updateBoard(p); saveData(); return true;
        }
        if (cmd.equals("setrank")) {
            if (!sender.hasPermission("berryessentials.rank")) { send(sender, "Tidak punya izin."); return true; }
            if (args.length != 2) { send(sender, "Gunakan /setrank <player> <rank>"); return true; }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null || !getConfig().isConfigurationSection("ranks." + args[1])) { send(sender, "Player atau rank tidak ditemukan di config."); return true; }
            ranks.put(target.getUniqueId(), args[1]); syncNametag(target); updateBoard(target); saveData(); send(sender, "Rank " + target.getName() + " diubah ke " + args[1]); return true;
        }
        if (cmd.equals("clan")) return clanCommand(sender, args);
        if (cmd.equals("sethome") || cmd.equals("home") || cmd.equals("delhome") || cmd.equals("setwarp") || cmd.equals("warp")) {
            send(sender, "Modul teleport belum diaktifkan di build ini."); return true;
        }
        if (cmd.equals("membermenu") || cmd.equals("adminmenu")) {
            if (!isPlayer(sender)) return true;
            if (cmd.equals("adminmenu") && !sender.hasPermission("berryessentials.admin")) { send(sender, "Tidak punya izin."); return true; }
            ((Player)sender).sendMessage("Menu GUI sedang disiapkan; gunakan command untuk modul yang tersedia.");
            return true;
        }
        return false;
    }

    private boolean clanCommand(CommandSender sender, String[] a) {
        if (!isPlayer(sender)) return true;
        Player p = (Player)sender; UUID id = p.getUniqueId();
        if (a.length == 0 || a[0].equalsIgnoreCase("info")) {
            send(p, "Clan: " + clans.getOrDefault(id, "Belum ada")); return true;
        }
        if (a[0].equalsIgnoreCase("create") && a.length == 2) {
            String name = a[1].toLowerCase(Locale.ROOT);
            if (!name.matches("[a-z0-9_]{3,12}") || clanOwners.containsKey(name) || clans.containsKey(id)) { send(p, "Nama tidak valid, sudah dipakai, atau kamu sudah punya clan."); return true; }
            clanOwners.put(name,id); clans.put(id,name); persistClans(); refreshAllBoards(); saveData(); send(p,"Clan dibuat: " + name); return true;
        }
        if (a[0].equalsIgnoreCase("join") && a.length == 2) {
            String name = a[1].toLowerCase(Locale.ROOT);
            if (!clanOwners.containsKey(name) || clans.containsKey(id)) { send(p,"Clan tidak ditemukan atau kamu sudah punya clan."); return true; }
            clans.put(id,name); refreshAllBoards(); saveData(); send(p,"Bergabung ke clan " + name); return true;
        }
        if (a[0].equalsIgnoreCase("leave")) {
            clans.remove(id); refreshAllBoards(); saveData(); send(p,"Kamu keluar dari clan."); return true;
        }
        send(p,"/clan create <nama> | /clan join <nama> | /clan leave | /clan info"); return true;
    }

    private void persistClans() {
        for (String key : new HashSet<>(Objects.requireNonNullElse(getConfig().getConfigurationSection("clans"), getConfig().createSection("clans")).getKeys(false)))
            getConfig().set("clans." + key, null);
        for (var e : clanOwners.entrySet()) getConfig().set("clans." + e.getKey() + ".owner", e.getValue().toString());
        saveConfig();
    }
    private void refreshAllBoards() { for (Player p : Bukkit.getOnlinePlayers()) { updateBoard(p); syncNametag(p); } }
}
